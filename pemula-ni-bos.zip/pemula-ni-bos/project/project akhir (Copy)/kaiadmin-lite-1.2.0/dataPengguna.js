class Pengguna {
  constructor() {
    this.dataPengguna = JSON.parse(localStorage.getItem("dataTransaksi")) || [];
  }

  tampilPengguna() {
    const tabelDataPengguna = document.getElementById("tabelDataPengguna");
    tabelDataPengguna.innerHTML = ""; // Kosongkan tabel terlebih dahulu

    // Cek apakah dataPengguna kosong
    if (this.dataPengguna.length === 0) {
      tabelDataPengguna.innerHTML =
        "<tr><td colspan='3'>Tidak ada data pengguna</td></tr>";
      return;
    }

    this.dataPengguna.forEach((pengguna, index) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
          <td>${index + 1}</td>
          <td>${pengguna.namaPeminjam}</td>
          <td>${pengguna.emailPeminjam}</td>
        `;
      tabelDataPengguna.appendChild(tr);
    });
  }
}

const pengguna = new Pengguna();
pengguna.tampilPengguna();
