class Barang {
  constructor() {
    this.dataBarang = JSON.parse(localStorage.getItem("dataBarang")) || [];
    this.tampilData();
  }

  tambahBarang() {
    const namaBarang = document.getElementById("namabarang").value;
    const stok = parseInt(document.getElementById("stok").value);
    const minStok = parseInt(document.getElementById("minimalstok").value);

    let dataBarang = JSON.parse(localStorage.getItem("dataBarang")) || [];

    let barangLama = dataBarang.find(
      (barang) => barang.namaBarang === namaBarang
    );

    if (barangLama) {
      barangLama.stok += stok;
    } else {
      dataBarang.push({ namaBarang, stok, minStok });
    }

    localStorage.setItem("dataBarang", JSON.stringify(dataBarang));

    const berhasil = document.getElementById("berhasil");
    berhasil.innerHTML = Swal.fire({
      position: "top-center",
      icon: "success",
      title: "Data telah ditambahkan",
      showConfirmButton: false,
      timer: 1500,
    });

    setTimeout(() => {
      berhasil.innerHTML = "";
    }, 1500);

    this.dataBarang = dataBarang;

    this.tampilData();

    console.log("Data barang tersimpan:", dataBarang);
  }

  tampilData() {
    let tabelDataBarang = document.getElementById("tabelDataBarang");
    tabelDataBarang.innerHTML = "";
    this.dataBarang.forEach((data, index) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${index + 1}</td>
        <td>${data.namaBarang}</td>
        <td>${data.stok}</td>
        <td>${data.minStok}</td>
      `;
      tabelDataBarang.appendChild(tr);
    });
  }
}

const barang = new Barang();
