document.getElementById("logout").addEventListener("click", (e) => {
  // Mencegah tindakan bawaan tombol logout
  e.preventDefault();

  Swal.fire({
    title: "Are you sure?",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes, log out!",
    cancelButtonText: "No, stay here!",
  }).then((result) => {
    if (result.isConfirmed) {
      // Tampilkan pesan sukses jika logout
      Swal.fire({
        title: "Logged out!",
        text: "You have been logged out successfully.",
        icon: "success",
        showConfirmButton: false,
        timer: 1500, // Pesan otomatis menghilang setelah 1.5 detik
      });

      // Pindahkan ke halaman index.html setelah animasi selesai
      setTimeout(() => {
        window.location.href = "index.html";
      }, 1500);
    } else if (result.dismiss === Swal.DismissReason.cancel) {
      // Pesan jika pengguna membatalkan logout
      Swal.fire({
        title: "Cancelled",
        icon: "info",
        showConfirmButton: false,
        timer: 1500,
      });
    }
  });
});
