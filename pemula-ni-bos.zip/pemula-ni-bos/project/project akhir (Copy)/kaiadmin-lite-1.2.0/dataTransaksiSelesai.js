class Pengguna {
  constructor() {
    this.dataTransaksiSelesai =
      JSON.parse(localStorage.getItem("dataTransaksiSelesai")) || [];
  }

  tampilPengguna() {
    const tabelDataPengguna = document.getElementById("tabelDataPengguna");
    tabelDataPengguna.innerHTML = ""; // Kosongkan tabel terlebih dahulu

    if (this.dataTransaksiSelesai.length === 0) {
      tabelDataPengguna.innerHTML =
        "<tr><td colspan='7'>Tidak ada data pengguna</td></tr>";
      return;
    }

    this.dataTransaksiSelesai.forEach((data, index) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
          <td>${index + 1}</td>
          <td>${data.namaPeminjam}</td>
          <td>${data.emailPeminjam}</td>
          <td>${data.barang}</td>
          <td>${data.jumlah}</td>
          <td>${data.tanggalpinjam}</td>
          <td>
            <button class='btn btn-danger btn-sm' onclick='pengguna.hapusPengguna(${index})'>
              Hapus Data
            </button>
          </td>
        `;
      tabelDataPengguna.appendChild(tr);
    });
  }

  hapusPengguna(index) {
    // Konfirmasi penghapusan
    Swal.fire({
      title: "Apakah Anda yakin?",
      text: "Data yang dihapus tidak dapat dikembalikan!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#3085d6",
      confirmButtonText: "Ya, hapus!",
      cancelButtonText: "Batal",
    }).then((result) => {
      if (result.isConfirmed) {
        // Hapus data dari array berdasarkan index
        this.dataTransaksiSelesai.splice(index, 1);

        // Simpan kembali array yang diperbarui ke localStorage
        localStorage.setItem(
          "dataTransaksiSelesai",
          JSON.stringify(this.dataTransaksiSelesai)
        );

        // Perbarui tampilan tabel
        this.tampilPengguna();

        // Tampilkan notifikasi berhasil
        Swal.fire({
          position: "top-center",
          icon: "success",
          title: "Data berhasil dihapus",
          showConfirmButton: false,
          timer: 1500,
        });
      }
    });
  }
}

const pengguna = new Pengguna();
pengguna.tampilPengguna();
