class Transaksi {
  constructor() {
    this.dataTransaksi =
      JSON.parse(localStorage.getItem("dataTransaksi")) || [];
    this.dataBarang = JSON.parse(localStorage.getItem("dataBarang")) || [];
    this.dataTransaksiSelesai =
      JSON.parse(localStorage.getItem("dataTransaksiSelesai")) || [];
    this.tampilData(); // Tampilkan data saat halaman dimuat
  }

  pinjamBarang() {
    const namaPeminjam = document.getElementById("namapeminjam").value;
    const emailPeminjam = document.getElementById("emailpeminjam").value;
    const namaBarang = document.getElementById("barang").value;
    const jumlah = parseInt(document.getElementById("jumlah").value);
    const tanggalpinjam = document.getElementById("tanggalpinjam").value;

    let dataBarang = JSON.parse(localStorage.getItem("dataBarang")) || [];
    let barang = dataBarang.find((item) => item.namaBarang === namaBarang);

    if (!barang || barang.stok < jumlah) {
      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: barang ? "Stok barang tidak cukup!" : "Barang tidak ditemukan!",
      });
      return;
    }

    barang.stok -= jumlah;
    localStorage.setItem("dataBarang", JSON.stringify(dataBarang));

    this.dataTransaksi.push({
      namaPeminjam,
      emailPeminjam,
      barang: namaBarang,
      jumlah,
      tanggalpinjam,
    });
    localStorage.setItem("dataTransaksi", JSON.stringify(this.dataTransaksi));

    this.tampilData();
    Swal.fire({
      position: "top-center",
      icon: "success",
      title: "Data telah ditambahkan",
      showConfirmButton: false,
      timer: 1500,
    });
  }

  tampilData() {
    let tabelDataTransaksi = document.getElementById("tabelDataTransaksi");
    tabelDataTransaksi.innerHTML = "";
    this.dataTransaksi.forEach((data, index) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${index + 1}</td>
        <td>${data.namaPeminjam}</td>
        <td>${data.emailPeminjam}</td>
        <td>${data.barang}</td>
        <td>${data.jumlah}</td>
        <td>${data.tanggalpinjam}</td>
        <td>
          <button class='btn btn-danger' onclick='transaksi.hapusTransaksi(${index})'>
            <i class='fa fa-trash'></i>
          </button>
        </td>
      `;
      tabelDataTransaksi.appendChild(tr);
    });
  }

  hapusTransaksi(index) {
    const transaksiYangDihapus = this.dataTransaksi.splice(index, 1)[0];
    const barang = this.dataBarang.find(
      (item) => item.namaBarang === transaksiYangDihapus.barang
    );

    if (barang) {
      barang.stok += transaksiYangDihapus.jumlah;
      localStorage.setItem("dataBarang", JSON.stringify(this.dataBarang));
    }

    // Tambahkan transaksi yang dihapus ke dataTransaksiSelesai
    this.dataTransaksiSelesai.push(transaksiYangDihapus);
    localStorage.setItem(
      "dataTransaksiSelesai",
      JSON.stringify(this.dataTransaksiSelesai)
    );

    localStorage.setItem("dataTransaksi", JSON.stringify(this.dataTransaksi));
    this.tampilData();

    Swal.fire({
      position: "top-center",
      icon: "success",
      title: "Data telah dihapus ",
      text: "barang telah dikembalikan",
      showConfirmButton: false,
      timer: 1500,
    });
  }
}

const transaksi = new Transaksi();
