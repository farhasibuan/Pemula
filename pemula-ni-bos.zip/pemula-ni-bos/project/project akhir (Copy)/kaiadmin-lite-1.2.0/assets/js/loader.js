document.addEventListener('DOMContentLoaded', () => {
    const loader = document.querySelector('.container-loader');
    
    // Tunggu 3 detik sebelum memulai transisi
    setTimeout(() => {
        loader.classList.add('hide');
    }, 1000); // 1000 ms = 3 detik
});
